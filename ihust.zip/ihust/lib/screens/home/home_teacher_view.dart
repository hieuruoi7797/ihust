part of 'home_screen.dart';
class HomeTeacherView extends StatefulWidget {
  @override
  _HomeTeacherViewState createState() => _HomeTeacherViewState();
}

class _HomeTeacherViewState extends State<HomeTeacherView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}