part of 'tabletime_bloc.dart';

abstract class TabletimeState extends Equatable {
  const TabletimeState();
}

class TabletimeInitial extends TabletimeState {
  @override
  List<Object> get props => [];
}
