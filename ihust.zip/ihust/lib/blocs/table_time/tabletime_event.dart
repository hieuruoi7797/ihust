part of 'tabletime_bloc.dart';

abstract class TabletimeEvent extends Equatable {
  const TabletimeEvent();
}
