class Routes {
  static final String home = "/home";
  static final String splash = "/";
  static final String login = "/login";
  static final String classes ="/classes";
  static final String projects = "/projects";
  static final String classDetail ="/classes/classdetail";
}
