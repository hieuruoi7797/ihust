class Config {
  static final BASE_URL ="https://set-hust.appspot.com/api?type=";
  static final  NULL_TXT = "";
  static final NULL_ID = -1;
  static final PAYMENT_TYPE_1A = 1;
  static final STATUS_UNDEFINED = -1;
  static final NOTIFY_NOT_YET = -1;
  static final PRIVACY_PUBLIC = 0;
  static final GENDER_MALE = 0;
  static final STATUS_OPENNED = 0;
  static final STAFF_STATUS_NORMAL = 0;
  static final STATUS_FAMILY_UNDEFINED = -1;
  static final TEXT_EMPTY = "";
}